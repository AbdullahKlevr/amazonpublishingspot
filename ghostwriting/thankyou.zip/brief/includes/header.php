<header>
    <div class="main-header">
        
        <div class="container">
            <div class="menu-Bar">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="row align-items-center">
                <div class="col-md-4 text-left">
                    <a href="./" class="logo">
                        <img src="assets/images/logo.svg" alt="">
                    </a>
                </div>
                <div class="col-md-8 text-right">
                    <div class="menuWrap">
                        <ul class="menu">
                            <li class="active"><a href="./">Home</a></li>
                            <li><a href="#">Company</a></li>
                            <li><a href="#">Products</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>