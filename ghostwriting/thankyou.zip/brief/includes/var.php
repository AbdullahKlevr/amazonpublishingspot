<?php
$brand ="Brand Name";
$url ="brandname.com";
$phone = " +1 (844) 212-4292";
$email = "support@brand.com";
$address = "5401 West Kennedy Blvd, Tampa, FL 33609";
$title = "Title";
$desc ="Description";

$basic = 99;
$standard = 199;
$premium  = 299;
   