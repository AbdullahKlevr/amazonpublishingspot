<section class="cta2">
    <div class="container aos-init aos-animate" data-aos="fade-up" data-aos-duration="2100">
        <div class="row g-4">
            <div class="col-md-6">
                <div class="info-cta2">
                    <h2>
                        Get Your Story Out in the World. <br>
                        Let Us Help You Write it!
                    </h2>
                    <p>
                        We can get you started on your journey to becoming a published author. Contact us today!
                    </p>
                    <div class="btn-wrap">
                        <a href="javascript:;" class="theme-btn popstatic">Get Started</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>