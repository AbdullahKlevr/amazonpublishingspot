<?php
    $brand = "lorem international";
    $phone = "+1 (727) 513-5653";
    $email = "info@amazonkdpexpert.com";
    $address = "3410 nectar ct Ontario ca 91761";
?>