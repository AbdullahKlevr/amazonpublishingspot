<div class="trusted-companies">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-12">
                <div class="">
                    <div class="site-logos">
                        <ul class="logos">
                            <li><img src="assets/images/site-logos/1.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                            <li><img src="assets/images/site-logos/2.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                            <li><img src="assets/images/site-logos/3.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                            <li><img src="assets/images/site-logos/4.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                            <li><img src="assets/images/site-logos/5.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                            <li><img src="assets/images/site-logos/6.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>