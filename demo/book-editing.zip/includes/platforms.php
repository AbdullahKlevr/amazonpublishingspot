<section class="">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-12">
                <div class="sec-heading center">
                    <h2>We Help You Become a Published Author</h2>
                    <p>We can help you get published on a variety of platforms </p>
                </div>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-lg-12">
                <div class="padding">
                    <div class="">
                        <ul class="logos">
                            <li><img src="assets/images/trusted/1.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                            <li><img src="assets/images/trusted/2.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                            <li><img src="assets/images/trusted/3.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                            <li><img src="assets/images/trusted/4.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                            <li><img src="assets/images/trusted/5.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                            <li><img src="assets/images/trusted/6.webp" alt="" loading="lazy" width="100px"
                                    height="100px"></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="rclient-item">
                    <a class="rc_play" data-fancybox="" href="https://www.youtube.com/watch?v=2eRUgEW9DF8">
                        <span class="play_btn"></span>
                        <img src="../i.ytimg.com/vi/2eRUgEW9DF8/maxresdefault.jpg" alt="">
                    </a>
                    <h3>Arthur Patrick</h3>
                </div>
            </div>

            <div class="col-md-4">
                <div class="rclient-item">
                    <a class="rc_play" data-fancybox="" href="https://www.youtube.com/watch?v=sAp7Zo7yiW4">
                        <span class="play_btn"></span>
                        <img src="../i.ytimg.com/vi/sAp7Zo7yiW4/maxresdefault.jpg" alt="">
                    </a>
                    <h3>Britney Sheldon</h3>
                </div>
            </div>

            <div class="col-md-4">
                <div class="rclient-item">
                    <a class="rc_play" data-fancybox="" href="https://www.youtube.com/watch?v=Dc09pw4WJf4">
                        <span class="play_btn"></span>
                        <img src="../i.ytimg.com/vi/Dc09pw4WJf4/maxresdefault.jpg" alt="">
                    </a>
                    <h3>Sharline Smith</h3>
                </div>
            </div>
        </div>
    </div>
</section>